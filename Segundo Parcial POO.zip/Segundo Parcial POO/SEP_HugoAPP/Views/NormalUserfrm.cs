﻿using SEP_HugoAPP.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SEP_HugoAPP.Views
{
    public partial class NormalUserfrm : Form
    {
        public AppUser user;
        public NormalUserfrm(AppUser u)
        {
            user = u;
            InitializeComponent();
            DoubleBuffered = true;
        }
    }
}
