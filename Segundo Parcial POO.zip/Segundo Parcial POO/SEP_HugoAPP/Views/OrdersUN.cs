﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SEP_HugoAPP.Model;
using System.Xml.Serialization;
using System.Reflection;

namespace SEP_HugoAPP.Views
{
    public partial class OrdersUN : UserControl
    {
        public OrdersUN()
        {
            InitializeComponent();
            DTGload();
            comboOrder();
            combosload();
        }

        private void SaveAddress_Click(object sender, EventArgs e)
        {
            try
            {
                int p = Convert.ToInt32(ProductoCombo.SelectedValue.ToString());
                int a = Convert.ToInt32(Addrescombo.SelectedValue.ToString());
                Order_DAO.AddOrder(p, a);
                MessageBox.Show("Pedido guardado");
                DTGload();
                comboOrder();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);

            }
        }
        public void DTGload()
        {
            DTGordersn.DataSource = Order_DAO.PersonalOrder();
        } 
        public void comboOrder()
        {
            ordercombo.DataSource = null;
            ordercombo.ValueMember = "Idorder";
            ordercombo.DisplayMember = "Idorder";
            ordercombo.DataSource = Order_DAO.PersonalOrder();
        }
        public void combosload()
        {
            ProductoCombo.DataSource = null;
            ProductoCombo.ValueMember = "IdProduct";
            ProductoCombo.DisplayMember = "Name";
            ProductoCombo.DataSource = Product_DAO.dtgproduct();

            Addrescombo.DataSource = null;
            Addrescombo.ValueMember = "Idaddress";
            Addrescombo.DisplayMember = "Idaddress";
            Addrescombo.DataSource = Address_DAO.QueryPersonalAddress();
        }
        private void deleteorder_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Seguguro que desea borrar el pedido?",
                    "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
                {
                    int a = Convert.ToInt32(ordercombo.SelectedValue.ToString());

                    Order_DAO.DeleteOrder(a);
                    MessageBox.Show("Pedido Eliminado");
                    comboOrder();
                    DTGload();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
