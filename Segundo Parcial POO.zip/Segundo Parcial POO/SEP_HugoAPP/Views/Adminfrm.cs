﻿using SEP_HugoAPP.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SEP_HugoAPP.Views
{
    public partial class Adminfrm : Form
    {
        public AppUser user;
        public Adminfrm(AppUser u)
        {
            user = u;
            InitializeComponent();
            try
            {
                DTGorders.DataSource = Order_DAO.Orders();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
                //throw;
            }

        }
        private void Comboload()
        {
            comboDelete.DataSource = null;
            comboDelete.ValueMember = "Iduser";
            comboDelete.DisplayMember = "Username";
            comboDelete.DataSource = AppUser_DAO.Userslist();
        }
        private void Deleteuserbuttom_Click_1(object sender, EventArgs e)
        {
            try
            {
                AppUser u = (AppUser)comboDelete.SelectedItem;
                if (MessageBox.Show("¿Seguro que desea eliminar al usuario?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    AppUser_DAO.DeleteUser(Convert.ToInt32(comboDelete.SelectedValue.ToString()));
                    MessageBox.Show("Usuario eliminado");
                    Comboload();
                    dtgsload();
                }
                else
                    clear();
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void clear()
        {
            newFullname.Clear();
            newusername.Clear();
        }

        private void comboDelete_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            Deleteuserbuttom.Enabled = true;
        }
        public void dtgsload()
        {
            DTGuser.DataSource = AppUser_DAO.dtgUser();
            dataGridView1.DataSource = Business_DAO.dtgBUSINESS();
            dataGridView2.DataSource = Product_DAO.dtgproduct();

        }

        private void Adminfrm_Load(object sender, EventArgs e)
        {
            Deleteuserbuttom.Enabled = false;
            Comboload();
            dtgsload();
            CombosPyNload();
        }
        private void Save_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("No puede dejar campos vacios");
                }
                else
                {
                    Business_DAO.AddBusiness(textBox1.Text, textBox2.Text);
                    //String sql = String.Format("INSERT INTO BUSINESS(name, description)" +
                    //$"VALUES('{textBox1.Text}', '{textBox2.Text}');");
                    //ConnectioDB.ExecuteNonQuery(sql);
                   MessageBox.Show("Nuevo negocio ingresado");
                    dtgsload();
                    CombosPyNload();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
                //throw;
            }
        }
        private void CombosPyNload()
        {
            comboBox1.DataSource = null;
            comboBox1.ValueMember = "IdBusiness";
            comboBox1.DisplayMember = "Name";
            comboBox1.DataSource = Business_DAO.businessList();

            comboBox3.DataSource = null;
            comboBox3.ValueMember = "IdBusiness";
            comboBox3.DisplayMember = "Name";
            comboBox3.DataSource = Business_DAO.businessList();

            comboBox2.DataSource = null;
            comboBox2.ValueMember = "IdProduct";
            comboBox2.DisplayMember = "Name";
            comboBox2.DataSource = Product_DAO.ProductList();
        }
        private void Eliminar_Click(object sender, EventArgs e)
        {
            try
            {
                Business u = (Business)comboBox1.SelectedItem;
                if (MessageBox.Show("¿Seguro que desea eliminarlo?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Business_DAO.DeleteBusiness(Convert.ToInt32(comboBox1.SelectedValue.ToString()));
                    MessageBox.Show("eliminado");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            dtgsload();
            CombosPyNload();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox3.Text == "")
                {
                    MessageBox.Show("No puede dejar campos vacios");
                }
                else
                {
                    Product_DAO.Addproduct(Convert.ToInt32(comboBox3.SelectedValue.ToString()), textBox3.Text);
                    MessageBox.Show("Nuevo producto ingresado");
                    dtgsload();
                    CombosPyNload();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            dtgsload();
            CombosPyNload();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Product u = (Product)comboBox2.SelectedItem;
                if (MessageBox.Show("¿Seguro que desea eliminarlo?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Product_DAO.Deleteproduct(Convert.ToInt32(comboBox2.SelectedValue.ToString()));
                    MessageBox.Show("eliminado");
                    CombosPyNload();
                    dtgsload();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            dtgsload();
            CombosPyNload();
        }
        private void Savenewuser_Click_1(object sender, EventArgs e)
        {

            try
            {
                if (newFullname.Text == "" || newusername.Text == "")
                {
                    MessageBox.Show("No pueden haber campos vacios");
                }
                else
                {
                    Boolean admin;
                    if (RadAdmin.Checked == true)
                    {
                        admin = true;
                        AppUser_DAO.AddUser(newFullname.Text, newusername.Text, admin);
                        Comboload();
                        dtgsload();
                        MessageBox.Show("Usuario agregado");
                    }
                    else if (RadUser.Checked == true)
                    {
                        admin = false;
                        AppUser_DAO.AddUser(newFullname.Text, newusername.Text, admin);
                        dtgsload(); Comboload();
                        MessageBox.Show("Usuario agregado");

                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }
    }
}
