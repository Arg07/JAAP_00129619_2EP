﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SEP_HugoAPP.Model;

namespace SEP_HugoAPP.Views
{
    public partial class OrdersviewAdmin : UserControl
    {
        public OrdersviewAdmin()
        {
            InitializeComponent();
        }

        private void OrdersviewAdmin_Load(object sender, EventArgs e)
        {
            
        }
    }
}
