﻿namespace SEP_HugoAPP.Views
{
    partial class NormalUserfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabcontrol = new System.Windows.Forms.TabControl();
            this.Addres = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.usernormal1 = new SEP_HugoAPP.Views.Usernormal();
            this.ordersUN1 = new SEP_HugoAPP.Views.OrdersUN();
            this.tabcontrol.SuspendLayout();
            this.Addres.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabcontrol
            // 
            this.tabcontrol.Controls.Add(this.Addres);
            this.tabcontrol.Controls.Add(this.tabPage2);
            this.tabcontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabcontrol.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabcontrol.Location = new System.Drawing.Point(0, 0);
            this.tabcontrol.Name = "tabcontrol";
            this.tabcontrol.SelectedIndex = 0;
            this.tabcontrol.Size = new System.Drawing.Size(1202, 639);
            this.tabcontrol.TabIndex = 0;
            // 
            // Addres
            // 
            this.Addres.BackgroundImage = global::SEP_HugoAPP.Properties.Resources.fondo;
            this.Addres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Addres.Controls.Add(this.usernormal1);
            this.Addres.Location = new System.Drawing.Point(4, 29);
            this.Addres.Name = "Addres";
            this.Addres.Padding = new System.Windows.Forms.Padding(3);
            this.Addres.Size = new System.Drawing.Size(1194, 606);
            this.Addres.TabIndex = 0;
            this.Addres.Text = "Direcciones";
            this.Addres.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ordersUN1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1194, 606);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Pedidos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // usernormal1
            // 
            this.usernormal1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.usernormal1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.usernormal1.Location = new System.Drawing.Point(3, 3);
            this.usernormal1.Margin = new System.Windows.Forms.Padding(4);
            this.usernormal1.Name = "usernormal1";
            this.usernormal1.Size = new System.Drawing.Size(1188, 600);
            this.usernormal1.TabIndex = 0;
            // 
            // ordersUN1
            // 
            this.ordersUN1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ordersUN1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ordersUN1.Location = new System.Drawing.Point(3, 3);
            this.ordersUN1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ordersUN1.Name = "ordersUN1";
            this.ordersUN1.Size = new System.Drawing.Size(1188, 600);
            this.ordersUN1.TabIndex = 0;
            // 
            // NormalUserfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SEP_HugoAPP.Properties.Resources.fondo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1202, 639);
            this.Controls.Add(this.tabcontrol);
            this.DoubleBuffered = true;
            this.Name = "NormalUserfrm";
            this.Text = "NormalUserfrm";
            this.tabcontrol.ResumeLayout(false);
            this.Addres.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabcontrol;
        private System.Windows.Forms.TabPage Addres;
        private Usernormal usernormal1;
        private System.Windows.Forms.TabPage tabPage2;
        private OrdersUN ordersUN1;
    }
}