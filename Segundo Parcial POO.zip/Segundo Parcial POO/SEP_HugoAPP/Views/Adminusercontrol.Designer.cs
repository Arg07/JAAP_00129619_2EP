﻿namespace SEP_HugoAPP.Views
{
    partial class Adminusercontrol
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Savenewuser = new System.Windows.Forms.Button();
            this.RadUser = new System.Windows.Forms.RadioButton();
            this.RadAdmin = new System.Windows.Forms.RadioButton();
            this.newusername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.newFullname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboDelete = new System.Windows.Forms.ComboBox();
            this.Deleteuserbuttom = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DTGuser = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DTGuser)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Indigo;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.436129F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.56495F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.56495F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.433981F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.DTGuser, 1, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.49933F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.433735F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.06693F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1050, 774);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.Controls.Add(this.Savenewuser);
            this.groupBox1.Controls.Add(this.RadUser);
            this.groupBox1.Controls.Add(this.RadAdmin);
            this.groupBox1.Controls.Add(this.newusername);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.newFullname);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(39, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(482, 307);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Agregar Nuevo Usuario";
            // 
            // Savenewuser
            // 
            this.Savenewuser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Savenewuser.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Savenewuser.ForeColor = System.Drawing.Color.Black;
            this.Savenewuser.Location = new System.Drawing.Point(167, 231);
            this.Savenewuser.Name = "Savenewuser";
            this.Savenewuser.Size = new System.Drawing.Size(103, 36);
            this.Savenewuser.TabIndex = 6;
            this.Savenewuser.Text = "Registrar";
            this.Savenewuser.UseVisualStyleBackColor = true;
            // 
            // RadUser
            // 
            this.RadUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RadUser.AutoSize = true;
            this.RadUser.Location = new System.Drawing.Point(211, 190);
            this.RadUser.Name = "RadUser";
            this.RadUser.Size = new System.Drawing.Size(156, 26);
            this.RadUser.TabIndex = 5;
            this.RadUser.TabStop = true;
            this.RadUser.Text = "Usuario Normal";
            this.RadUser.UseVisualStyleBackColor = true;
            // 
            // RadAdmin
            // 
            this.RadAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RadAdmin.AutoSize = true;
            this.RadAdmin.Location = new System.Drawing.Point(94, 190);
            this.RadAdmin.Name = "RadAdmin";
            this.RadAdmin.Size = new System.Drawing.Size(85, 26);
            this.RadAdmin.TabIndex = 4;
            this.RadAdmin.TabStop = true;
            this.RadAdmin.Text = "Admin";
            this.RadAdmin.UseVisualStyleBackColor = true;
            // 
            // newusername
            // 
            this.newusername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newusername.Location = new System.Drawing.Point(94, 143);
            this.newusername.Name = "newusername";
            this.newusername.Size = new System.Drawing.Size(273, 29);
            this.newusername.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Username";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // newFullname
            // 
            this.newFullname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newFullname.Location = new System.Drawing.Point(94, 76);
            this.newFullname.Name = "newFullname";
            this.newFullname.Size = new System.Drawing.Size(200, 29);
            this.newFullname.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(90, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre Completo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.Controls.Add(this.comboDelete);
            this.groupBox2.Controls.Add(this.Deleteuserbuttom);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(527, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(482, 307);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Eliminar usuario";
            // 
            // comboDelete
            // 
            this.comboDelete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboDelete.FormattingEnabled = true;
            this.comboDelete.Location = new System.Drawing.Point(125, 143);
            this.comboDelete.Name = "comboDelete";
            this.comboDelete.Size = new System.Drawing.Size(218, 30);
            this.comboDelete.TabIndex = 7;
            // 
            // Deleteuserbuttom
            // 
            this.Deleteuserbuttom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Deleteuserbuttom.ForeColor = System.Drawing.Color.Black;
            this.Deleteuserbuttom.Location = new System.Drawing.Point(179, 232);
            this.Deleteuserbuttom.Name = "Deleteuserbuttom";
            this.Deleteuserbuttom.Size = new System.Drawing.Size(105, 36);
            this.Deleteuserbuttom.TabIndex = 6;
            this.Deleteuserbuttom.Text = "Registrar";
            this.Deleteuserbuttom.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(160, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Seleccione el Usuario";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label3, 2);
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(252, 332);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(544, 49);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lista de Usuarios Registrados";
            // 
            // DTGuser
            // 
            this.DTGuser.AllowUserToAddRows = false;
            this.DTGuser.AllowUserToDeleteRows = false;
            this.DTGuser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DTGuser.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DTGuser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.DTGuser, 2);
            this.DTGuser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DTGuser.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DTGuser.Location = new System.Drawing.Point(39, 388);
            this.DTGuser.Name = "DTGuser";
            this.DTGuser.ReadOnly = true;
            this.DTGuser.RowHeadersWidth = 51;
            this.DTGuser.RowTemplate.Height = 24;
            this.DTGuser.Size = new System.Drawing.Size(970, 383);
            this.DTGuser.TabIndex = 3;
            // 
            // Adminusercontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(7)))), ((int)(((byte)(99)))));
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Adminusercontrol";
            this.Size = new System.Drawing.Size(1050, 774);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DTGuser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Savenewuser;
        private System.Windows.Forms.RadioButton RadUser;
        private System.Windows.Forms.RadioButton RadAdmin;
        private System.Windows.Forms.TextBox newusername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox newFullname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboDelete;
        private System.Windows.Forms.Button Deleteuserbuttom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView DTGuser;
    }
}
