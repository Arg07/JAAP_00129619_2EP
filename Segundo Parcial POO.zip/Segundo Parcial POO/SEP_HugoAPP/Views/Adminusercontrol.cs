﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SEP_HugoAPP.Model;

namespace SEP_HugoAPP.Views
{
    public partial class Adminusercontrol : UserControl
    {
        public Adminusercontrol()
        {
            InitializeComponent();
            Deleteuserbuttom.Enabled = false;
            Comboload();
            DTGuser.DataSource = AppUser_DAO.dtgUser();
        }
        private void Comboload()
        {
            // Actualizar ComboBox
            comboDelete.DataSource = null;
            comboDelete.ValueMember = "Iduser";
            comboDelete.DisplayMember = "Username";
            comboDelete.DataSource = AppUser_DAO.Userslist();
        }
        private void Savenewuser_Click(object sender, EventArgs e)
        {
            try
            {
                if (newFullname.Text == "" || newusername.Text == "")
                {
                    MessageBox.Show("No pueden haber campos vacios");
                }
                else
                {
                    Boolean admin;
                    if (RadAdmin.Checked == true)
                    {
                        admin = true;
                        AppUser_DAO.AddUser(newFullname.Text, newusername.Text, admin);
                    }
                    else if (RadUser.Checked == true)
                    {
                        admin = false;
                        AppUser_DAO.AddUser(newFullname.Text, newusername.Text, admin);
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
           
        }

        private void Deleteuserbuttom_Click(object sender, EventArgs e)
        {
            try
            {
                AppUser u = (AppUser)comboDelete.SelectedItem;
                if (MessageBox.Show("¿Seguro que desea eliminar al usuario?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    AppUser_DAO.DeleteUser(Convert.ToInt32(comboDelete.SelectedValue.ToString()));
                    MessageBox.Show("Usuario eliminado");
                }
                else
                    clear();
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void clear()
        {
            newFullname.Clear();
            newusername.Clear();
            RadUser.Checked = true;
        }

        private void comboDelete_SelectedIndexChanged(object sender, EventArgs e)
        {
            Deleteuserbuttom.Enabled = true;
        }
    }
}
