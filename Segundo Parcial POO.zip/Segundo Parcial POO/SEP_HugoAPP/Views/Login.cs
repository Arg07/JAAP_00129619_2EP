﻿using SEP_HugoAPP.Model;
using SEP_HugoAPP.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SEP_HugoAPP
{
    public partial class login : Form
    {

        
        public login()
        {
            InitializeComponent();
        }

        private void loginbutton_Click(object sender, EventArgs e)
        {
            try
            {
                AppUser u = (AppUser)combousers.SelectedItem;
                if (passtxt.Text.Equals(u.Password .ToString()))
                {
                    
                    if (u.UserType==true)
                    {
                        Address_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));
                        Order_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));
                        MessageBox.Show("Accediendo como Admin, Bienvenido");
                        Adminfrm ventana = new Adminfrm(u);
                        ventana.Show();
                        this.Hide();
                    }

                    else
                    {
                        Address_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));
                        Order_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));
                        MessageBox.Show("Accediendo, Bienvenido");
                        NormalUserfrm ventana = new NormalUserfrm(u);
                        ventana.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("La contraseña ingresada no coincide con el usuario");

                }
            }
            catch (Exception)
            {

                throw;
            }

        }
        private void login_Load(object sender, EventArgs e)
        {
            try
            {
                AppUser_DAO.Userslist();
                Comboload();

            }
            catch (Exception)
            {
                MessageBox.Show("Error de conexion", "Error");
            }
        }
        private void Comboload()
        {
            // Actualizar ComboBox
            combousers.DataSource = null;
            combousers.ValueMember = "Password";
            combousers.DisplayMember = "Username";
            combousers.DataSource = AppUser_DAO.Userslist();
        }

        private void combousers_SelectedIndexChanged(object sender, EventArgs e)
        {
            AppUser u = (AppUser)combousers.SelectedItem;
            Address_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));
            Order_DAO.queryiduser(Convert.ToInt32(u.Iduser.ToString()));

        }
    }
}
