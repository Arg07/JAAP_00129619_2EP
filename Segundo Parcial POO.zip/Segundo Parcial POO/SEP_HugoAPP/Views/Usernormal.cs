﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SEP_HugoAPP.Model;
using System.Security.Cryptography.X509Certificates;

namespace SEP_HugoAPP.Views
{
    public partial class Usernormal : UserControl
    {
        public AppUser user;
        public Usernormal(AppUser u)
        {
            user = u;
            InitializeComponent();
            DTGA();
            combo();
        }
        public Usernormal()
        {
            InitializeComponent();
            DTGA();
            combo();
        }

        private void SaveAddress_Click(object sender, EventArgs e)
        {
            try
            {
                String a = $"{d1.Text}, " + $"{d2.Text}, " + $"{d3.Text}, " + $"{d4.Text}";
                Address_DAO.AddAdress(a);
                MessageBox.Show("Datos guardados", "aviso");

                clear(); DTGA(); combo();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }
        public void clear()
        {
            d1.Clear(); d2.Clear(); d3.Clear(); d4.Clear();
            textBox4.Clear(); textBox3.Clear(); textBox2.Clear(); textBox1.Clear();
        }
        public void combo()
        {
            comboBox1.DataSource = null;
            comboBox1.ValueMember = "Idaddress";
            comboBox1.DisplayMember = "Idaddress";
            comboBox1.DataSource = Address_DAO.QueryPersonalAddress();
        }
        public void DTGA()
        {
            DTGAddres.DataSource=  Address_DAO.QueryPersonalAddress();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String a = $"{textBox1.Text}, " + $"{textBox2.Text}, " + $"{textBox3.Text}, " + $"{textBox4.Text}";
                int i = Convert.ToInt32(comboBox1.SelectedValue.ToString());
                Address_DAO.UpdateAddress(i, a);
                MessageBox.Show("Datos actualizados", "aviso");
                clear(); DTGA(); combo();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);            }
            
        }

        private void delete_Click(object sender, EventArgs e)
        {
            try
            {
                int i = Convert.ToInt32(comboBox1.SelectedValue.ToString());
                Address_DAO.DeleteAddress(i);
                MessageBox.Show("Datos borrados", "aviso");
                clear(); DTGA(); combo();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }
    }
}
