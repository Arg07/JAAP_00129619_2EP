﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public class AppUser
    {
        public int Iduser { get; set; }
        public String Fullname { get; set; }
        public String Username { get; set; }
        public String Password { get; set; }
        public bool UserType { get; set; }

        public AppUser() { }
        public AppUser(int iduser, string fullname, string username, string password, bool userType)
        {
            this.Iduser = iduser;
            this.Fullname = fullname;
            this.Username = username;
            this.Password = password;
            this.UserType = userType;
        }
       
    }
}
