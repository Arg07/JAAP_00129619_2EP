﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public static class Product_DAO
    {
        public static List<Product> ProductList()
        {
            String sql = String.Format("SELECT * FROM PRODUCT");
            DataTable dt = ConnectioDB.ExecuteQuery(sql);
            List<Product> Productlist = new List<Product>();
            foreach (DataRow r in dt.Rows)
            {
                Product b = new Product();
                b.IdProduct = Convert.ToInt32(r[0].ToString());
                b.IdBusiness = Convert.ToInt32(r[1].ToString()); ;
                b.Name = r[2].ToString();

                Productlist.Add(b);
            }
            return Productlist;
        }
        public static void Addproduct(int i, String prod)
        {
            String sql = String.Format("INSERT INTO PRODUCT(idBusiness, name)" +
                "VALUES({0}, '{1}');", i, prod);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void Deleteproduct(int idp)
        {
            String sql = String.Format("DELETE FROM PRODUCT WHERE idProduct = {0};", idp);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static DataTable dtgproduct()
        {
            String sql = String.Format("SELECT * FROM PRODUCT");
            DataTable dt = ConnectioDB.ExecuteQuery(sql);
            return dt;
        }

    }
}
