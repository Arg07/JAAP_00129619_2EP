﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    class Business_DAO
    {
        public static List<Business> businessList()
        {
            String sql = "SELECT * FROM BUSINESS";
            var dt = ConnectioDB.ExecuteQuery(sql);
            List<Business> businessList = new List<Business>();
            foreach (DataRow r in dt.Rows)
            {
                Business b = new Business();
                b.IdBusiness = Convert.ToInt32(r[0].ToString());
                b.Name = r[1].ToString();
                b.Description = r[2].ToString();

                businessList.Add(b);
            }
            return businessList;
        }
        public static void AddBusiness(String name, String description)
        {
            String sql = String.Format("INSERT INTO BUSINESS(name, description)" +
                "VALUES('{0}', '{1}');", name, description);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static int QueryIDbusiness(String b)
        {
            String sql = String.Format("SELECT \"idBusiness\" FROM BUSINESS WHERE name= '{0}';",b);
            var dt = ConnectioDB.ExecuteQuery(sql);
            DataRow r = dt.Rows[0];
            int i = Convert.ToInt32(r[0].ToString());
            return i;
        }
        public static void DeleteBusiness(int idB)
        {
            String sql = String.Format("DELETE FROM BUSINESS WHERE idBusiness = {0};", idB);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static DataTable dtgBUSINESS()
        {
            String query = "select * from BUSINESS";
            var dt = ConnectioDB.ExecuteQuery(query);
            return dt;
        }
    }
}
