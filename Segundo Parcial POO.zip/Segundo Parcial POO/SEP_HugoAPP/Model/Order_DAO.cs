﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public class Order_DAO
    {
        public static int IDusernormal;

        public static List<Order> OrdertList()
        {
            String sql = String.Format("SELECT * FROM APPORDER");
            DataTable dt = ConnectioDB.ExecuteQuery(sql);
            List<Order> Productlist = new List<Order>();
            foreach (DataRow r in dt.Rows)
            {
                Order o = new Order();
                o.Idorder = Convert.ToInt32(r[0].ToString());
                o.Order_date = DateTime.Parse(r[1].ToString());
                o.Idproduct = Convert.ToInt32(r[2].ToString());
                o.Idaddress = Convert.ToInt32(r[3].ToString());

                Productlist.Add(o);
            }
            return Productlist;
        }
        public static void queryiduser(int iuserN)
        {
            IDusernormal = iuserN;
        }

        public static DataTable Orders()
        {
            String sql = "SELECT ao.idOrder, ao.createDate, pr.name, au.fullname, ad.address " +
                "FROM APPORDER ao, ADDRESS ad, PRODUCT pr, APPUSER au " +
                "WHERE ao.idProduct = pr.idProduct " +
                "AND ao.idAddress = ad.idAddress " +
                "AND ad.idUser = au.idUser";
            DataTable dt = ConnectioDB.ExecuteQuery(sql);
            return dt;
        }
        public static DataTable PersonalOrder()
        {
            String sql = String.Format("SELECT ao.idOrder, ao.createDate, pr.name, au.fullname, ad.address " +
                "FROM APPORDER ao, ADDRESS ad, PRODUCT pr, APPUSER au " +
                "WHERE ao.idProduct = pr.idProduct " +
                "AND ao.idAddress = ad.idAddress " +
                "AND ad.idUser = au.idUser " +
                "AND au.idUser = {0};", IDusernormal);
            DataTable dt = ConnectioDB.ExecuteQuery(sql);
            return dt;
        }
        public static void AddOrder(int idp, int ida)
        {
            DateTime.Now.ToString("yyyy/MM/dd");
            String sql = String.Format("INSERT INTO APPORDER(createDate, idProduct, idAddress) " +
                "VALUES('{0}', {1}, {2});", DateTime.Now.ToString("yyyy/MM/dd"), idp, ida);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void DeleteOrder(int idO)
        {
            String sql = String.Format("DELETE FROM APPORDER WHERE idOrder = {0}", idO);
            ConnectioDB.ExecuteNonQuery(sql);
        }
    }
}
