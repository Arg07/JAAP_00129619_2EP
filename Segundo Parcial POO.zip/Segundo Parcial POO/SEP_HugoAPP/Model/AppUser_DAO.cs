﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SEP_HugoAPP.Model
{
    public static class AppUser_DAO
    {
#pragma warning disable IDE1006 // Estilos de nombres
        public static List<AppUser> Userslist()
        {
            //consultar tabla de usuarios en la BD
            String query = "select * from APPUSER";
            var dt = ConnectioDB.ExecuteQuery(query);
            //almacenar los datos en una lista
            List<AppUser> UserList = new List<AppUser>();
            foreach (DataRow dr in dt.Rows)
            {
                AppUser u = new AppUser();
                u.Iduser = Convert.ToInt32(dr[0].ToString());
                u.Fullname = dr[1].ToString();
                u.Username = dr[2].ToString();
                u.Password = dr[3].ToString();
                u.UserType = Convert.ToBoolean(dr[4].ToString());

                UserList.Add(u);
            }
            return UserList;
        }
        public static void AddUser(String Fullname, String user, Boolean typeU)
        {
            String sql = "INSERT INTO APPUSER(fullname, username, password, userType)" +
                $"VALUES('{Fullname}', '{user}', '{user}', {typeU});";
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void UpdatePass(int idU, String newpass)
        {
            String sql = String.Format("UPDATE APPUSER SET password = '{0}' " +
                "WHERE \"idUser\" ={1};", newpass, idU);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void DeleteUser(int idUser)
        {
            String sql = String.Format("DELETE FROM APPUSER WHERE idUser = {0};", idUser);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static int QueryIDUser(String b)
        {
            String sql = String.Format("SELECT idUser FROM APPUSER WHERE name= '{0}';", b);
            var dt = ConnectioDB.ExecuteQuery(sql);
            DataRow r = dt.Rows[0];
            int i = Convert.ToInt32(r[0].ToString());
            return i;
        }
        public static DataTable dtgUser()
        {
            String query = "select * from APPUSER";
            var dt = ConnectioDB.ExecuteQuery(query);
            return dt;
        }

    }
}
