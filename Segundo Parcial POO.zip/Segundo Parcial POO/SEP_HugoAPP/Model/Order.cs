﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public class Order
    {
        public int Idorder { get; set; }
        public DateTime Order_date { get; set; }
        public int Idproduct { get; set; }
        public int Idaddress { get; set; }

        public Order()
        {

        }
        public Order(int idorder, DateTime order_date, int idproduct, int idaddress)
        {
            Idorder = idorder;
            Order_date = order_date;
            Idproduct = idproduct;
            Idaddress = idaddress;
        }
    }
}
