﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public class Business
    {
        public int IdBusiness { get; set;}
        public String Name { get; set; }
        public String Description { get; set; }

        public Business() { }
        public Business(int idBusiness, string name, string description)
        {
            IdBusiness = idBusiness;
            Name = name;
            this.Description = description;
        }
    }
}
