﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SEP_HugoAPP.Model
{
    public class Address_DAO
    {
        public static int IDusernormal;
        public static List<Address> Addreslist()
        {
            String query = "SELECT * FROM ADDRESS";
            var dt = ConnectioDB.ExecuteQuery(query);
            List<Address> addressList = new List<Address>();

            foreach (DataRow r in dt.Rows)
            {
                Address a = new Address();
                a.Idaddress = Convert.ToInt32(r[0].ToString());
                a.Iduser = Convert.ToInt32(r[1].ToString());
                a.Addres = r[2].ToString();
            }
            return addressList;
        }
        public static void queryiduser(int iuserN)
        {
            IDusernormal = iuserN;
        }
        public static void UpdateAddress(int idAddress, String newAdsress)
        {
            String sql = String.Format("UPDATE ADDRESS SET address = '{1}' " +
                "WHERE idAddress = {0};",idAddress, newAdsress);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void AddAdress(String newA)
        {
            String sql = String.Format("INSERT INTO ADDRESS(idUser, address)" +
                "VALUES({0},'{1}');",IDusernormal, newA);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static void DeleteAddress(int i)
        {
            String sql = String.Format("DELETE FROM ADDRESS WHERE idAddress ={0};", i);
            ConnectioDB.ExecuteNonQuery(sql);
        }
        public static DataTable QueryPersonalAddress()
        {
            String sql = String.Format("SELECT ad.idAddress, ad.address FROM ADDRESS" +
                " ad WHERE idUser = {0};", IDusernormal);
           var dt = ConnectioDB.ExecuteQuery(sql);
            return dt;
        }
    }
}
