﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEP_HugoAPP.Model
{
    public class Product
    {
        public int IdProduct { get; set; }
        public int IdBusiness { get; set; }
        public String Name { get; set; }

        public Product()
        {
        }
        public Product(int idProduct, int idBusiness, string name)
        {
            IdProduct = idProduct;
            IdBusiness = idBusiness;
            this.Name = name;
        }
    }
}
